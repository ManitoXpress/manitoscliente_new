import 'package:flutter/material.dart';

class MyTextStyles {
  static const TextStyle inputTextStyle = TextStyle(
    color: Color(0xFF000405),
    fontSize: 14,
    fontFamily: 'Xpress Heavy',
    fontWeight: FontWeight.bold,
    fontStyle: FontStyle.italic,
  );
  static const TextStyle titleStyle = TextStyle(
    color: Color(0xFFFFFFFF),
    fontSize: 22, // Tamaño más grande para el título
    fontFamily: 'Xpress Heavy',
    fontWeight: FontWeight.bold, // Negrita para el título
  );

  static const TextStyle titleStyle1 = TextStyle(
    color: Color(0xFFFFFFFF),
    fontSize: 22, // Tamaño más grande para el título
    fontFamily: 'Xpress',
    fontWeight: FontWeight.w200,
    fontStyle: FontStyle.normal, // Negrita para el título
  );

  static const TextStyle tabTextStyle = TextStyle(
    fontSize: 10,
    color: Color.fromARGB(255, 0, 0, 0),
    fontFamily: 'Xpress',
    fontWeight: FontWeight.w700,
    fontStyle: FontStyle.italic,
  );

  static const TextStyle tabTextStyle1 = TextStyle(
    fontSize: 12,
    color: Color(0xFFFFFFFF),
    fontFamily: 'Xpress',
    fontWeight: FontWeight.w700,
    fontStyle: FontStyle.normal,
  );

  static const TextStyle buttonTextStyle = TextStyle(
    color: Color(0xFFFFFFFF),
    fontSize: 18,
    fontFamily: 'Xpress',
    fontWeight: FontWeight.w700,
    fontStyle: FontStyle.italic,
  );

  static const TextStyle inputTextStyle7 = TextStyle(
    color: Color(0xFF000405),
    fontSize: 22,
    fontFamily: 'Xpress',
    fontWeight: FontWeight.w700,
    fontStyle: FontStyle.normal,
  );

  static const TextStyle buttonTextStyle3 = TextStyle(
    fontSize: 24,
    color: Color(0xFF1A819A),
    fontFamily: 'Xpress',
    fontWeight: FontWeight.w200,
    fontStyle: FontStyle.normal,
  );
  static const TextStyle loginWelcomeStyle = TextStyle(
    fontSize: 25,
    fontFamily: 'Xpress Heavy',
    color: Color(0xFF1A819A),
    fontWeight: FontWeight.bold,
  );
  static const TextStyle welcomeTotheJungle = TextStyle(
    color: Color(0xFF1A819A),
    fontFamily: 'Xpress',
    fontWeight: FontWeight.w600,
    fontStyle: FontStyle.normal,
    fontSize: 25.0,
  );

  static const TextStyle linkTextStyle = TextStyle(
    color: Color(0xFF1A819A),
    fontSize: 18,
    fontFamily: 'Xpress',
    fontWeight: FontWeight.w700,
    fontStyle: FontStyle.italic,
  );

  static const TextStyle appBarTitleTextStyle = TextStyle(
    color: Colors.white,
    fontFamily: 'Xpress Heavy',
    fontWeight: FontWeight.bold,
    fontSize: 18,
  );

  static const TextStyle unselectedTabTextStyle = TextStyle(
    fontSize: 10,
    color: Color.fromARGB(255, 0, 0, 0),
    fontFamily: 'Xpress',
    fontWeight: FontWeight.w700,
    fontStyle: FontStyle.italic,
  );

  static const TextStyle drawerButtonTextStyle = TextStyle(
    color: Color(0xFF000405),
    fontFamily: 'Xpress Heavy',
    fontWeight: FontWeight.bold,
    fontSize: 18.0,
  );

  static const TextStyle drawerButtonTextStyle7 = TextStyle(
    color: Color(0xC5282A2A),
    fontFamily: 'Xpress',
    fontWeight: FontWeight.w700,
    fontStyle: FontStyle.italic,
    fontSize: 14.0,
  );
  static const TextStyle servicesButtonTextStyle = TextStyle(
    color: Color(0xFF000405),
    fontFamily: 'Xpress Heavy',
    fontWeight: FontWeight.bold,
    fontSize: 14.0,
  );
  static const TextStyle drawerButtonTextStyle2 = TextStyle(
    color: Color.fromARGB(255, 0, 0, 0),
    fontFamily: 'Xpress',
    fontWeight: FontWeight.w700,
    fontStyle: FontStyle.italic,
    fontSize: 20.0,
  );
  static const TextStyle drawerButtonTextStyle8 = TextStyle(
    color: Color(0xFF1A819A),
    fontFamily: 'Xpress',
    fontWeight: FontWeight.w700,
    fontStyle: FontStyle.italic,
    fontSize: 20.0,
  );

  static const TextStyle CategoriaButtonTextStyle = TextStyle(
    color: Color(0xFFFFFFFF),
    fontFamily: 'Xpress Heavy',
    fontWeight: FontWeight.bold,
    fontSize: 35.0,
  );
  static const TextStyle notification = TextStyle(
    color: Color(0xFF1A819A),
    fontFamily: 'Xpress Heavy',
    fontWeight: FontWeight.bold,
    fontSize: 20.0,
  );
  static const TextStyle drawerButtonTextStyle3 = TextStyle(
    color: Color.fromARGB(255, 0, 0, 0),
    fontFamily: 'Xpress',
    fontWeight: FontWeight.w700,
    fontStyle: FontStyle.italic,
    fontSize: 20.0,
  );

  static const TextStyle drawerButtonTextStyle1 = TextStyle(
    color: Color.fromARGB(255, 0, 0, 0),
    fontFamily: 'Xpress',
    fontWeight: FontWeight.w700,
    fontStyle: FontStyle.italic,
    fontSize: 17.0,
  );

  static const TextStyle ButtonTextStyle = TextStyle(
    color: Color(0xFF000405),
    fontFamily: 'Xpress',
    fontWeight: FontWeight.w200,
    fontStyle: FontStyle.normal,
    fontSize: 15.0,
  );
  static const TextStyle drawerButtonTextStyle4 = TextStyle(
    color: Color(0xFF1A819A),
    fontFamily: 'Xpress Heavy',
    fontWeight: FontWeight.bold,
  );
  static const TextStyle drawerButtonTextStyle5 = TextStyle(
    color: Color(0xFF000405),
    fontFamily: 'Xpress Heavy',
    fontWeight: FontWeight.w800,
    fontSize: 15.0,
  );
  static const TextStyle serviceTextStyle = TextStyle(
    color: Color(0xFF000405),
    fontFamily: 'Xpress',
    fontWeight: FontWeight.w700,
    fontStyle: FontStyle.italic,
    fontSize: 14.0,
  );

  static const TextStyle navBarTextStyle = TextStyle(
    fontFamily: 'Xpress',
    fontWeight: FontWeight.w200,
    fontStyle: FontStyle.normal,
  );

  static const TextStyle linkTextStyle2 = TextStyle(
    color: Color(0xFF841813),
    fontFamily: 'Xpress Heavy',
    fontWeight: FontWeight.bold,
  );

  static const TextStyle drawerButtonLabelTextStyle = TextStyle(
    color: Colors.white,
    fontFamily: 'Xpress',
    fontWeight: FontWeight.w700,
    fontStyle: FontStyle.italic,
  );
  static const TextStyle serviceTitleTextStyle = TextStyle(
    fontSize: 16,
    color: Colors.white,
    fontFamily: 'Xpress',
    fontWeight: FontWeight.w200,
    fontStyle: FontStyle.normal,
  );

  static const TextStyle serviceTitleTextStyle2 = TextStyle(
    fontSize: 16,
    color: Color(0xFF000405),
    fontFamily: 'Xpress Heavy', // Nombre de la fuente
    fontWeight: FontWeight.bold,
  );
  static const TextStyle formServiceTextStyle = TextStyle(
    color: Color(0xFF000405),
    fontFamily: 'Xpress',
    fontWeight: FontWeight.w200,
    fontStyle: FontStyle.normal,
    fontSize: 17.0,
  );
  static const TextStyle formServiceTextStyle2 = TextStyle(
    color: Color(0xFF000405),
    fontFamily: 'Xpress',
    fontWeight: FontWeight.w700,
    fontStyle: FontStyle.normal,
    fontSize: 17.0,
  );
  static const TextStyle formServiceTextStyle3 = TextStyle(
    color: Color(0xFF000405),
    fontFamily: 'Xpress Heavy',
    fontWeight: FontWeight.bold,
    fontSize: 15.0,
  );
  static const TextStyle titleTextStyle = TextStyle(
    color: Color(0xFF000405),
    fontFamily: 'Xpress Heavy',
    fontWeight: FontWeight.bold,
    fontSize: 22.0,
  );
  static const TextStyle butServiceTextStyle = TextStyle(
    color: Color(0xFFFFFFFF),
    fontFamily: 'Xpress Heavy',
    fontWeight: FontWeight.bold,
    fontSize: 28.0,
  );
  static const TextStyle formsdetails = TextStyle(
    color: Color(0xA3606262),
    fontFamily: 'Xpress Heavy',
    fontWeight: FontWeight.bold,
    fontSize: 12.0,
  );

  static const TextStyle formsdetails1 = TextStyle(
    color: Color.fromARGB(255, 20, 20, 20),
    fontFamily: 'Xpress',
    fontWeight: FontWeight.w200,
    fontStyle: FontStyle.normal,
    fontSize: 14.0,
  );
  static const TextStyle drawerButtonTextStyle6 = TextStyle(
    color: Color(0xFF1A819A),
    fontFamily: 'Xpress',
    fontWeight: FontWeight.w200,
    fontStyle: FontStyle.normal,
    fontSize: 18.0,
    decoration: TextDecoration.underline, // Subrayado
    decorationColor: Color(0xFF1A819A), // Color del subrayado
    decorationThickness: 0.8,
  );
  static const TextStyle inputTextStyle4 = TextStyle(
    color: Color(0xFF000405),
    fontSize: 22,
    fontFamily: 'Xpress',
    fontWeight: FontWeight.w700,
    fontStyle: FontStyle.italic,
  );
  static const TextStyle welcomeTotheJungle1 = TextStyle(
    color: Color(0xFF1A819A),
    fontFamily: 'Xpress',
    fontWeight: FontWeight.w700,
    fontStyle: FontStyle.italic,
    fontSize: 25.0,
  );

  static const TextStyle welcomeTotheJungle2 = TextStyle(
    color: Color(0xFF1A819A),
    fontFamily: 'Xpress',
    fontWeight: FontWeight.w700,
    fontStyle: FontStyle.italic,
    fontSize: 30.0,
  );

  static const TextStyle inputTextStyle3 = TextStyle(
    color: Color(0xFF000405),
    fontSize: 16,
    fontFamily: 'Xpress',
    fontWeight: FontWeight.w700,
    fontStyle: FontStyle.italic,
  );

  static const TextStyle tittleButton = TextStyle(
    color: Color(0xFF1A819A),
    fontFamily: 'Xpress',
    fontWeight: FontWeight.w600,
    fontStyle: FontStyle.normal,
    fontSize: 18,
  );

  static const TextStyle inputTextStyle1 = TextStyle(
    color: Color(0xFF000405),
    fontSize: 19,
    fontFamily: 'Xpress',
    fontWeight: FontWeight.w200,
    fontStyle: FontStyle.normal,
  );

  static const TextStyle inputTextStyle6 = TextStyle(
    color: Color(0xFF000405),
    fontSize: 19,
    fontFamily: 'Xpress',
    fontWeight: FontWeight.w700,
    fontStyle: FontStyle.italic,
  );
}

class MyColors {
  static const Color main = Color(0xFF1A819A); // Color principal
  static const Color accent = Color(0xFF841813); // Color secundario/acento
  static const Color badge = Color(0xFF1A819A); // Badge principal (puedes ajustar)
  static const Color badgeAccent = Color(0xFF841813); // Badge acento
  static const Color tabSelectedBg = Color(0x1A1A819A); // Fondo tab seleccionado (10% opacity)
  static const Color tabUnselected = Color(0xFF000405); // Texto tab no seleccionado
}
