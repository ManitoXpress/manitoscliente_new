import 'dart:convert';

import 'package:cloud_firestore/cloud_firestore.dart';


import 'dart:convert';

import '../main.dart';
import '../controller/baseurl.dart';
import '../request/ResponseGet.dart';
import '../request/ResponsePost.dart';
import '../request/requestExpertise.dart';
import '../request/requestServiceType.dart';
import '../request/requestStatus.dart';
import '../request/resquest.dart';
import 'cacheLocal.dart';

class ServiceRepository {
  final ApiService apiService;
  final FirebaseFirestore firestore;
  final String baseUrl = ApiConfiguration.baseUrl;

  ServiceRepository({required this.apiService, required this.firestore});

  // Función pública que permite filtrar servicios por estado desde Firestore
  Future<List<ServiceRequest>> fetchServicesByStatus(
    String status,
    String userId,
    String column,
    String token,
    List<Offer> offers, // Agregado el parámetro de ofertas
  ) async {
    // Obtener la lista de estados válidos desde Firestore
    List<String> validStatuses = await _getValidStatusesFromFirestore();

    // Validar el estado proporcionado con los valores de Firestore
    if (!validStatuses.contains(status)) {
      throw ArgumentError('Estado no válido: $status');
    }

    // Llamar al método privado para realizar la lógica principal
    return await _fetchServicesByStatus(status, column, userId, token, offers);
  }

  // Método privado para obtener los estados válidos desde Firestore
  Future<List<String>> _getValidStatusesFromFirestore() async {
    try {
      QuerySnapshot querySnapshot =
          await firestore.collection('services').get();

      Set<String> statusSet = {};

      for (var doc in querySnapshot.docs) {
        var data = doc.data() as Map<String, dynamic>;
        if (data.containsKey('status')) {
          statusSet.add(data['status'] as String);
        }
      }

      if (statusSet.isNotEmpty) {
        return statusSet.toList();
      } else {
        throw Exception('No se encontraron estados válidos en Firestore.');
      }
    } catch (e) {
      throw Exception('Error al obtener estados desde Firestore: $e');
    }
  }

  // Método privado para obtener los servicios por estado
  Future<List<ServiceRequest>> _fetchServicesByStatus(
    String type,
    String column,
    String userId,
    String token,
    List<Offer> offers,
  ) async {
    try {
      // No usamos la caché local de dispositivo aquí porque puede tener
      // datos stale (p.ej. el servicio cambió a 'offer' y perdió sus ofertas).
      // La caché real del Provider (SharedPreferences) maneja este nivel.
      final deviceId = await obtenerDeviceId();

      final response = await ApiService2().getAllServices(
        token,
        "userId",
        column,
        type,
      );

      if (response.statusCode == 200) {
        final List<Map<String, dynamic>> servicesData =
            List<Map<String, dynamic>>.from(
          json.decode(response.body),
        );

        if (servicesData.isNotEmpty) {
          try {
            final List<ServiceRequest> serviceRequestsList = servicesData
                .map((item) {
                  final statusName = item['status'] as String? ?? 'available';
                  final statusObject = Status(
                    id: statusName,
                    name: Status.getNameById(statusName),
                  );

                  final List<dynamic> expertisesArray =
                      item['expertises'] as List<dynamic>? ?? [];
                  final Map<String, dynamic> expertiseItem =
                      expertisesArray.isNotEmpty ? expertisesArray.first : {};

                  return ServiceRequest(
                    createdAt: DateTime.now(),
                    expertises: [
                      Expertise(
                        id: expertiseItem['id'] ?? '',
                        name: expertiseItem['name'] ?? '',
                      )
                    ],
                    id: item['id'] ?? '',
                    serviceDateTime: item['serviceDateTime'] ?? '',
                    description: item['description'] ?? '',
                    images: (item['images'] as List<dynamic>?)
                            ?.map((image) => image as String? ?? '')
                            .toList() ??
                        [],
                    location: Map<String, double>.from(
                      (item['location'] as Map<String, dynamic>?)
                              ?.map((key, value) {
                            return MapEntry(
                                key, (value is int) ? value.toDouble() : value);
                          }) ??
                          {},
                    ),
                    offeredPrice: _parseOfferedPrice(item['offeredPrice']),
                    userId: item['userId'] ?? '',
                    workerId: item['workerId'] ?? '',
                    status: statusObject,
                    isFavorite: item['isFavorite'] as bool? ?? false,
                    acceptedTerms: item['acceptedTerms'] as bool? ?? false,
                    serviceType: ServiceType(
                      name: item['serviceType'] ?? '',
                      id: '',
                      selectedDate: item['date'] ?? '',
                      selectedTime: item['time'] ?? '',
                    ),
                    selectedDate: item['date'] ?? '',
                    selectedTime: item['time'] ?? '',
                    devicesId: '',
                    hasOffer: item['hasOffer'] as bool? ?? false,
                    offers: [],
                    subcategoryName: item['subcategoryName'] ?? '',
                  );
                })
                .where((service) =>
                    (service.status.id == 'available' ||
                        service.status.id == 'offer') &&
                    service.userId == column)
                .toList();

            // Guardamos en caché local para referencia futura
            for (var request in serviceRequestsList) {
              LocalCacheService.cacheServiceRequest(request);
            }
            return serviceRequestsList;
          } catch (e) {
            return [];
          }
        } else {
          return [];
        }
      } else {
        return [];
      }
    } catch (e) {
      return [];
    }
  }

  // Método privado para parsear el precio ofrecido
  double _parseOfferedPrice(dynamic value) {
    if (value is String) {
      try {
        return double.parse(value);
      } catch (e) {
        null;
        return 0.0;
      }
    } else if (value is num) {
      return value.toDouble();
    }
    return 0.0;
  }
}
